

/** 
 * public interface IAVLNode
 * ! Do not delete or modify this - otherwise all tests will fail !
 */
public interface IAVLNode {

	public int getKey(); // Returns node's key (for virtual node return -1).
	public String getValue(); // Returns node's value [info], for virtual node returns null.
	public void setLeft(IAVLNode node); // Sets left child.
	public IAVLNode getLeft(); // Returns left child, if there is no left child returns null.
	public void setRight(IAVLNode node); // Sets right child.
	public IAVLNode getRight(); // Returns right child, if there is no right child return null.
	public void setParent(IAVLNode node); // Sets parent.
	public IAVLNode getParent(); // Returns the parent, if there is no parent return null.
	public boolean isRealNode(); // Returns True if this is a non-virtual AVL node.
	public void setHeight(int height); // Sets the height of the node.
	public int getHeight(); // Returns the height of the node (-1 for virtual nodes).
}
